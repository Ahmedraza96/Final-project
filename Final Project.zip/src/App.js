import React from 'react';
import logo from './logo.svg';
import './App.css';
import Header from './Components/Header/Header.js';
import Banner from './Components/Banner/Banner';
import Features from './Components/Features/Features';
import Main from './Components/Main/Main';
import Footer from './Components/Footer/Footer';



class App extends React.Component {
  render() {
    return (
      <div className="App">
        <Header />
        <Banner />
        <Features />
        <Main />
        <Footer />
        {/* <div>
          <h1>Hello User</h1>
        </div> */}
      </div>
    )
  };
}
export default App;
