import React from 'react';
import './style.css'
// import img from './images/room 2.jpg'

class Features extends React.Component {
    render() {
        return (
            <div id="features-wrapper">
                <div className="container">
                    <div className="row">
                        <div className="col-4 col-12-medium">

                            {/* <!-- Box --> */}
                            <section className="box feature">
                                <a href="#" className="image featured"><img src={require('./images/room 3.jpg')} alt="" /></a>
                                <div className="inner">
                                    <header>
                                        <h2>Put something here</h2>
                                        <p>Maybe here as well I think</p>
                                    </header>
                                    <p>Phasellus quam turpis, feugiat sit amet in, hendrerit in lectus. Praesent sed semper amet bibendum tristique fringilla.</p>
                                </div>
                            </section>

                        </div>
                        <div className="col-4 col-12-medium">

                            {/* <!-- Box --> */}
                            <section className="box feature">
                                <a href="#" className="image featured"><img src={require('./images/room 3.jpg')} alt="" /></a>
                                <div className="inner">
                                    <header>
                                        <h2>An interesting title</h2>
                                        <p>This is also an interesting subtitle</p>
                                    </header>
                                    <p>Phasellus quam turpis, feugiat sit amet in, hendrerit in lectus. Praesent sed semper amet bibendum tristique fringilla.</p>
                                </div>
                            </section>

                        </div>
                        <div className="col-4 col-12-medium">

                            {/* <!-- Box --> */}
                            <section className="box feature">
                                <a href="#" className="image featured"><img src={require('./images/room 3.jpg')} alt="" /></a>
                                <div className="inner">
                                    <header>
                                        <h2>Oh, and finally ...</h2>
                                        <p>Here's another intriguing subtitle</p>
                                    </header>
                                    <p>Phasellus quam turpis, feugiat sit amet in, hendrerit in lectus. Praesent sed semper amet bibendum tristique fringilla.</p>
                                </div>
                            </section>

                        </div>
                    </div>
                </div>
            </div>
        )
    };
}

export default Features;
