import React from 'react';
import './style.css'



class Header extends React.Component {
    render() {
        return (
            <div id="header-wrapper">
                <header id="header" className="container">

                    {/* <!-- Logo --> */}
                    <div id="logo">
                        <h1><a href="#">Taiba Travel & Tours</a></h1>
                        <span></span>
                    </div>

                    {/* <!-- Nav --> */}
                    <nav id="nav">
                        <ul>
                            <li className="current"><a href="#">Welcome</a></li>
                            <li>
                                <a href="#">Dropdown</a>
                                <ul>
                                    <li><a href="#">Lorem ipsum dolor</a></li>
                                    <li><a href="#">Magna phasellus</a></li>
                                    <li>
                                        <a href="#">Phasellus consequat</a>
                                        <ul>
                                            <li><a href="#">Lorem ipsum dolor</a></li>
                                            <li><a href="#">Phasellus consequat</a></li>
                                            <li><a href="#">Magna phasellus</a></li>
                                            <li><a href="#">Etiam dolore nisl</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="#">Veroeros feugiat</a></li>
                                </ul>
                            </li>
                            <li><a href="left-sidebar.html">About us</a></li>
                            <li><a href="right-sidebar.html">Contact us</a></li>
                            <li><a href="no-sidebar.html">Login</a></li>
                        </ul>
                    </nav>

                </header>
            </div>
        )
    };
}

export default Header;